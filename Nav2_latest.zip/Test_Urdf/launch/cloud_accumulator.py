import rclpy
import rclpy.time
import rclpy.duration
import rclpy.parameter
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, PointCloud2
from nav_msgs.msg import Odometry
from std_msgs.msg import Header
import laser_geometry.laser_geometry as lg
import sensor_msgs_py.point_cloud2 as pc2
import tf2_ros
import tf2_sensor_msgs.tf2_sensor_msgs as tf2_sm
import math

class CloudAccumulator(Node):
    def __init__(self):
        super().__init__('cloud_accumulator')

        self.set_parameters([rclpy.parameter.Parameter(
            'use_sim_time',
            rclpy.parameter.Parameter.Type.BOOL, True
        )])

        self.lp = lg.LaserProjection()
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.sub = self.create_subscription(LaserScan, '/scan', self.callback, 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom_fused', self.odom_callback, 10)

        self.pub = self.create_publisher(PointCloud2, '/odom_cloud', 10)

        self.voxel_grid = {}
        self.all_points = []
        self.angular_velocity = 0.0
        self.linear_velocity = 0.0
        self.voxel_size = 0.05

        self.min_translation = 0.02
        self.last_x = None
        self.last_y = None
        self.last_yaw = None

    def odom_callback(self, msg):
        self.angular_velocity = msg.twist.twist.angular.z
        self.linear_velocity = msg.twist.twist.linear.x

    def voxel_key(self, x, y, z):
        return (
            int(x / self.voxel_size),
            int(y / self.voxel_size),
            int(z / self.voxel_size)
        )

    def get_yaw_from_transform(self, t):
        q = t.transform.rotation
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny, cosy)

    def callback(self, msg):
        cloud_lidar = self.lp.projectLaser(msg)

        try:
            transform = self.tf_buffer.lookup_transform(
                'odom',
                'lidar',
                rclpy.time.Time(),
                timeout=rclpy.duration.Duration(seconds=0.3)
            )

            cx = transform.transform.translation.x
            cy = transform.transform.translation.y
            cyaw = self.get_yaw_from_transform(transform)

            if self.last_x is not None:
                dx = cx - self.last_x
                dy = cy - self.last_y
                dyaw = abs(cyaw - self.last_yaw)
                dist = math.sqrt(dx * dx + dy * dy)

                if dist < self.min_translation and dyaw < 0.05:
                    return

            self.last_x = cx
            self.last_y = cy
            self.last_yaw = cyaw

            cloud_odom = tf2_sm.do_transform_cloud(cloud_lidar, transform)
            new_points = list(pc2.read_points(
                cloud_odom, field_names=("x", "y", "z"), skip_nans=True))

            added = False
            for p in new_points:
                key = self.voxel_key(p[0], p[1], p[2])
                if key not in self.voxel_grid:
                    self.voxel_grid[key] = True
                    self.all_points.append(p)
                    added = True

            if added:
                header = Header()
                header.frame_id = 'odom'
                header.stamp = self.get_clock().now().to_msg()
                accumulated = pc2.create_cloud_xyz32(header, self.all_points)
                self.pub.publish(accumulated)

        except Exception as e:
            self.get_logger().warn(f'TF error: {str(e)}')

def main():
    rclpy.init()
    node = CloudAccumulator()
    rclpy.spin(node)

if __name__ == '__main__':
    main()
