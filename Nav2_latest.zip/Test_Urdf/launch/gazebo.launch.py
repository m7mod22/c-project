# ============================================================
#  gazebo.launch.py — Diff Drive Plugin approach
#
#  What changed vs old launch:
#   - REMOVED: mecanum_drive_controller / diff_drive_controller spawner
#   - REMOVED: odom_tf_broadcaster.py  (plugin publishes TF directly)
#   - REMOVED: EKF node
#   - KEPT:    joint_state_broadcaster, lidar_tilt_controller, SLAM
#
#  TF chain: map → (SLAM) → odom → (diff_drive plugin) → base_link
# ============================================================

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_path = get_package_share_directory('Test_Urdf')
    urdf_file = os.path.join(pkg_path, 'urdf', 'Test_Urdf.urdf')

    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    return LaunchDescription([

        # 1. Start Gazebo
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                get_package_share_directory('gazebo_ros'),
                '/launch/gazebo.launch.py'
            ]),
            launch_arguments={
                'world': os.path.join(pkg_path, 'worlds', 'empty.world')
            }.items()
        ),

        # 2. Robot description
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{
                'robot_description': robot_desc,
                'use_sim_time': True,
                'publish_frequency': 100.0
            }],
            output='screen'
        ),

        # 3. Spawn robot
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=[
                '-topic', 'robot_description',
                '-entity', 'test_urdf',
                '-x', '0.0', '-y', '-14', '-z', '0.8'  # z=0.1 — just above ground
            ],
            output='screen'
        ),

        # 4. Spawn map SDF
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=[
                '-file', os.path.join(pkg_path, 'urdf', 'map.sdf'),
                '-entity', 'map',
                '-x', '0', '-y', '0', '-z', '0'
            ],
            output='screen'
        ),

        # 7. SLAM Toolbox: /odom (from diff_drive plugin) + /scan → map→odom TF
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[
                os.path.join(pkg_path, 'config', 'slam_toolbox.yaml'),
                {'use_sim_time': True}
            ]
            # No remapping — SLAM reads /odom directly from the plugin
        ),
    ])
