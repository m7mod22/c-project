import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration
from sensor_msgs.msg import LaserScan
import sys
import tty
import termios
import select

class LidarTilt(Node):
    def __init__(self):
        super().__init__('lidar_tilt')

        # Joint controller publisher
        self.pub = self.create_publisher(
            JointTrajectory,
            '/lidar_tilt_controller/joint_trajectory',
            10
        )

        # ← Scan gate: subscribes to raw scan, republishes to SLAM only in Mode 1
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_gate, 10)
        self.scan_pub = self.create_publisher(
            LaserScan, '/scan_slam', 10)

        self.tilted = False
        self.current_angle = 0.0
        self.gate_open = True          # ← True = Mode 1, scans flow to SLAM
        self.returning = False         # ← True = lidar is physically returning

        self.hold_timer = self.create_timer(0.1, self.hold_position)

        self.get_logger().info(
            'Mode 1 (SLAM active) | Press T → Mode 2 (3D scan) | T again → Mode 1 | Q to quit')

    def scan_gate(self, msg):
        """Only forward scans to SLAM when gate is open (Mode 1)."""
        if self.gate_open:
            self.scan_pub.publish(msg)

    def set_joint(self, angle):
        self.current_angle = angle
        msg = JointTrajectory()
        msg.header.frame_id = 'base_link'
        msg.joint_names = ['jointl']
        point = JointTrajectoryPoint()
        point.positions = [angle]
        point.time_from_start = Duration(sec=1, nanosec=0)
        msg.points = [point]
        self.pub.publish(msg)

    def hold_position(self):
        msg = JointTrajectory()
        msg.header.frame_id = 'base_link'
        msg.joint_names = ['jointl']
        point = JointTrajectoryPoint()
        point.positions = [self.current_angle]
        point.time_from_start = Duration(sec=0, nanosec=100000000)
        msg.points = [point]
        self.pub.publish(msg)

    def enter_mode2(self):
        self.get_logger().info('>>> MODE 2: Gate CLOSED → Tilting to 90°')
        self.gate_open = False         # ← Close gate FIRST, instant
        self.set_joint(-1.5708)        # ← Then tilt
        self.tilted = True

    def enter_mode1(self):
        self.get_logger().info('>>> MODE 1: Returning to 0° → Gate opens after 1.5s')
        self.set_joint(0.0)            # ← Start returning
        self.tilted = False
        self.returning = True
        # ← Wait for lidar to physically reach 0° before reopening gate
        self.create_timer(1.5, self.open_gate_once)

    def open_gate_once(self):
        """One-shot: open gate only after lidar is physically horizontal."""
        if self.returning:
            self.gate_open = True
            self.returning = False
            self.get_logger().info('>>> Gate OPEN → SLAM resumed')

    def run(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while rclpy.ok():
                rclpy.spin_once(self, timeout_sec=0.05)
                if select.select([sys.stdin], [], [], 0)[0]:
                    key = sys.stdin.read(1)
                    if key in ('t', 'T'):
                        if not self.tilted:
                            self.enter_mode2()
                        else:
                            self.enter_mode1()
                    elif key in ('q', 'Q'):
                        break
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

def main():
    rclpy.init()
    node = LidarTilt()
    node.run()

if __name__ == '__main__':
    main()
